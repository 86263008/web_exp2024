class Student:
  '''学生表'''
  
  '''学号'''
  No: str = None

  '''姓名'''
  Name: str = None

  '''年龄'''
  Age: int = 0