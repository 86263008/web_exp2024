[toc]

# Tornado实验

## 1 实验类型

验证型，2学时，必选实验

## 2 实验目的

掌握Tonado不同类型请求参数的实现方法；

## 3 实验内容与要求

以不同的方式向Tornado传递参数。

## 4 实验环境

`Microsoft Edge/Chrome/Firefox`等浏览器，`Visual Studio Code`，`REST Client`，`Python 3.4+`，`Tornado`

## 5 步骤

### 安装依赖

1. 创建工作目录`WORK_DIR=学号`，最终目录结构如下（包含创建的各类文件）：

```shell
学号:.
    get_test.http
    get_test.py
    post_test.http
    post_test.py
    request_test.http
    request_test.py
    requirements.txt
    route_test.http
    route_test.py
```

> 注：后续代码均在工作目录创建

2. 创建虚拟环境`.venv`

```shell
py -m venv .venv
```

3. 激活虚拟环境：

```shell
.venv\scripts\activate
```

4. 安装依赖包：

```shell
pip install tornado
```

### 路由模块

利用路由模块处理不同类型的请求

1. 创建`route_test.py`实现不同类型的*路由*处理程序，如：

```python
# route_test.py
import tornado.ioloop
from tornado.web import RequestHandler, Application

class MainHandler(tornado.web.RequestHandler):
  def get(self):
    self.write("Hello, world")

class IndexHandler(RequestHandler):
  def get(self):
    self.write('welcome to IndexHandler')

class UserHandler(RequestHandler):
  def get(self, name):
    self.write(f'welcome {name}')

def make_app():
  return Application([
    (r"/", MainHandler),
    (r'/index', IndexHandler),
    (r'/user/(.*)', UserHandler)
  ])

if __name__ == "__main__":
  app = make_app()
  app.listen(8888)
  tornado.ioloop.IOLoop.current().start()
```

2. 启动服务器

```shell
py route_test.py
```

> 注：后续实验启动方式类似不再赘述

3. 编写*REST Client*测试代码(`route_test.http`)并测试发送请求，如：

```shell
@host = http://127.0.0.1:8888

### test /
GET {{host}}/ HTTP/1.1

### test /index
GET {{host}}/index HTTP/1.1

### test /user/*
GET {{host}}/user/his%20teamate HTTP/1.1
```

### 使用RequestHandler处理请求

自定义继承RequestHandler的子类并实现特定的方法

1. 创建`request_test.py`，编写自定义处理器访问*request*对象，如：

```python
import tornado.ioloop
from tornado.web import RequestHandler, Application

class HelloHandler(RequestHandler):
  def get(self):
    print(self.request.headers)             # 字典形式存储的headers信息
    print(self.request.headers['host'])     # 获取某一个首部
    print(self.request.path)                # 请求的path
    self.write('ok')

import tornado.ioloop
from tornado.web import RequestHandler, Application
from tornado.httpserver import HTTPServer

class HelloHandler(RequestHandler):
  def get(self):
    print(self.request.headers)             # 字典形式存储的headers信息
    print(self.request.headers['host'])     # 获取某一个首部
    print(self.request.path)                # 请求的path
    self.write('ok')

def make_app():
  return Application([
    (r'/', HelloHandler)
  ])

if __name__ == "__main__":
  app = make_app()
  app.listen(8888)
  tornado.ioloop.IOLoop.current().start()
```

2. 编写*REST Client*测试代(`request_test.http`)码并测试发送请求，如：

```shell
@host = http://127.0.0.1:8888

### test /
GET {{host}}/ HTTP/1.1
```

### 获取get请求参数

tornado使用get_argument方法获取get请求的参数

1. 创建`get_test.py`，编写自定义处理器获取*get*请求参数，如：

```python
import tornado.ioloop
from tornado.web import RequestHandler, Application

class HelloHandler(RequestHandler):
  def get(self):
    name = self.get_argument('name')
    age = self.get_argument('age')
    city = self.get_argument('city', default='beijing')
    self.write(f'{name} is {age} years old, he comes from {city}')

def make_app():
  return Application([
    (r'/', HelloHandler)
  ])

if __name__ == "__main__":
  app = make_app()
  app.listen(8888)
  tornado.ioloop.IOLoop.current().start()
```

2. 编写*REST Client*测试代码(`get_test.http`)并测试发送请求，如：

```shell
@host = http://127.0.0.1:8888

### test /
GET {{host}}/?name=andy&age=14  HTTP/1.1
```

### 获取post请求数据，并返回json数据

分别处理*form*和*json*格式的请求数据

1. 创建`post_test.py`，编写自定义处理器获取post请求参数，如：

```python
import json
import tornado.ioloop
from tornado.web import RequestHandler, Application

class FormHandler(RequestHandler):
  '''Form数据处理'''
  def post(self):
    name = self.get_argument('name')
    age = self.get_argument('age')
    self.write(f'{name} is {age} years old')

class JsonHandler(RequestHandler):
  '''JSON数据处理'''
  def post(self):
    data = json.loads(self.request.body)
    self.write(data)

def make_app():
  return Application([
    (r'/form', FormHandler),
    (r'/json', JsonHandler)
  ])

if __name__ == "__main__":
  app = make_app()
  app.listen(8888)
  tornado.ioloop.IOLoop.current().start()
```

2. 编写*REST Client*测试代码(`post_test.http`并测试发送请求，如：

```shell
@host = http://127.0.0.1:8888

### test /form
POST {{host}}/form  HTTP/1.1
Content-Type: application/x-www-form-urlencoded

name=andy&age=14

### test /json
POST {{host}}/json  HTTP/1.1
Content-Type: application/json

{
  "name": "andy",
  "age": 14
}
```