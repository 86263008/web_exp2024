function sayHello(name) {
  alert("Hello " + name)
}